create function st_astext(text)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT ST_AsText($1::public.geometry);
$$;

alter function st_astext(text)
  owner to postgres;

