create function st_count(rastertable text, rastercolumn text, exclude_nodata_value boolean)
  returns bigint
stable
strict
language sql
as $$
SELECT public._ST_count($1, $2, 1, $3, 1)
$$;

comment on function st_count(text, text, boolean)
is 'args: rastertable, rastercolumn, exclude_nodata_value - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

alter function st_count(text, text, boolean)
  owner to postgres;

