create function st_summarystats(rast raster, exclude_nodata_value boolean)
  returns summarystats
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_summarystats($1, 1, $2, 1)
$$;

comment on function st_summarystats(raster, boolean)
is 'args: rast, exclude_nodata_value - Returns summarystats consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(raster, boolean)
  owner to postgres;

