create function st_colormap(rast raster, colormap text, method text DEFAULT 'INTERPOLATE'::text)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_ColorMap($1, 1, $2, $3)
$$;

alter function st_colormap(raster, text, text)
  owner to postgres;

