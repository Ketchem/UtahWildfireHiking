create function st_transform(rast raster, srid integer, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_gdalwarp($1, $3, $4, $2, $5, $6)
$$;

comment on function st_transform(raster, integer, text, double precision, double precision, double precision)
is 'args: rast, srid, algorithm=NearestNeighbor, maxerr=0.125, scalex, scaley - Reprojects a raster in a known spatial reference system to another known spatial reference system using specified resampling algorithm. Options are NearestNeighbor, Bilinear, Cubic, CubicSpline, Lanczos defaulting to NearestNeighbor.';

alter function st_transform(raster, integer, text, double precision, double precision, double precision)
  owner to postgres;

