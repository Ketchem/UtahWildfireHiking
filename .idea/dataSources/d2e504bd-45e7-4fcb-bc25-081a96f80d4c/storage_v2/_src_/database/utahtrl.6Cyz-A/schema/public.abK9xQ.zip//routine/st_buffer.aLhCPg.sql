create function st_buffer(geometry, double precision, integer)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_Buffer($1, $2,
		CAST('quad_segs='||CAST($3 AS text) as cstring))

$$;

comment on function st_buffer(geometry, double precision, integer)
is 'args: g1, radius_of_buffer, num_seg_quarter_circle - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

alter function st_buffer(geometry, double precision, integer)
  owner to postgres;

